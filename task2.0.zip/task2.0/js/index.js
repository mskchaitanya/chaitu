$(document).ready(
		function() {

			// adding image pop-up functionality on hover of the image div

			$('.img_div').hover(function() {
				$(this).css({
					'z-index' : '10'
				});
				$(this).stop().animate({
					marginTop : '-20px',
					marginLeft : '-40px',
					top : '0',
					left : '0',
					width : '280px',
					height : '200px',

				}, 'slow');
				$(this).find('img').stop().animate({
					marginTop : '0',
					marginLeft : '0',
					top : '0',
					left : '0',
					width : '240px',
					height : '180px',

				}, 'slow');

			}, function() {
				$(this).css({
					'z-index' : '0'
				});
				$(this).stop().animate({
					marginTop : '0',
					marginLeft : '0',
					top : '0',
					left : '0',
					width : '200px',
					height : '150px',

				}, 'slow');
				$(this).find('img').stop().animate({
					marginTop : '0px',
					marginLeft : '0',
					top : '0',
					left : '0',
					width : '130px',
					height : '130px',

				}, 'slow');

			});

			// On click event adding an action to show full-screen view for the
			// picture selected
			$('.img_div').click(
					function() {

						$('.backdrop, .box').animate({
							'opacity' : '.50'
						}, 300, 'linear');
						$('.box').animate({
							'opacity' : '1.00'
						}, 300, 'linear');
						$('.backdrop, .box').css('display', 'block');
						var $myduplicate_image = $(this).find('img').clone();
						$('.box').html($myduplicate_image).append(
								'<div id="btnclose" class="close">X</div>');

					});

			$('#btnclose').live('click', function() {
				close_box();
			});

			$('.backdrop').live('click', function() {
				close_box();
			});
			
			$('.main_content:eq(0)').show();
			$('.nav a').live('click', function() {
				$('.nav a').removeClass('active');	
				$(this).addClass('active');	
				var active=$(this).attr('href');
				$('.main_content').hide();
				$(active).show();
			});
			
			
			

		});

// close function
function close_box() {
	$('.backdrop, .box').animate({
		'opacity' : '0'
	}, 300, 'linear', function() {
		$('.backdrop, .box').css('display', 'none');
	});
}
